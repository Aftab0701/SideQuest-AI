import React, { useEffect, useState } from "react";
import { 
  Home, 
  Target, 
  Search, 
  Settings, 
  Plus, 
  Wifi, 
  Battery, 
  ShieldAlert, 
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Command,
  HelpCircle,
  FolderOpen
} from "lucide-react";
import { CapturedItem, Mission, SmartReminder, ProductivityStats, ChatConversation } from "./types";
import Dashboard from "./screens/Dashboard";
import CaptureWorkspace from "./screens/CaptureWorkspace";
import MissionsBoard from "./screens/MissionsBoard";
import KnowledgeBase from "./screens/KnowledgeBase";
import SettingsScreen from "./screens/SettingsScreen";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [capturedItems, setCapturedItems] = useState<CapturedItem[]>([]);
  const [missions, setMissions] = useState<Mission[]>([]);
  const [reminders, setReminders] = useState<SmartReminder[]>([]);
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [userPreferences, setUserPreferences] = useState({
    ollamaUrl: "http://localhost:11434",
    ollamaModel: "llama3.2",
    aiMode: "gemini" as "local" | "gemini" | "hybrid",
    offlineMode: false,
    apiEndpoint: ""
  });
  
  const [stats, setStats] = useState<ProductivityStats>({
    score: 0,
    streakDays: 0,
    capturedCount: 0,
    distilledCount: 0,
    completedMissionsCount: 0,
    unfinishedIntentsCount: 0,
    tasksAtRiskCount: 0,
    urgencyNudgesCount: 0
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [showNotification, setShowNotification] = useState<{ message: string; type: "success" | "info" | "error" } | null>(null);
  const [showCaptureModal, setShowCaptureModal] = useState<boolean>(false);

  // Helper to dynamically resolve full API URLs for native APK / WebView compatibility
  const getApiUrl = (path: string): string => {
    let base = userPreferences.apiEndpoint;
    
    // Auto-detect browser location in web mode to avoid hardcoding issues
    if (!base && typeof window !== "undefined") {
      const origin = window.location.origin;
      if (origin && !origin.includes("capacitor://") && !origin.includes("http://localhost:3000") && !origin.includes("http://127.0.0.1:3000")) {
        base = origin;
      }
    }
    
    // Fallback default Cloud Run instance
    if (!base) {
      base = "https://ais-dev-lv6rkcyvurlp2lmi6qdqz7-404080228449.asia-southeast1.run.app";
    }
    
    const cleanPath = path.startsWith("/") ? path : `/${path}`;
    const cleanBase = base.endsWith("/") ? base.slice(0, -1) : base;
    return `${cleanBase}${cleanPath}`;
  };

  // Sync / fetch all data on startup
  const fetchData = async () => {
    try {
      const res = await fetch(getApiUrl("/api/data"));
      const data = await res.json();
      if (data) {
        setCapturedItems(data.capturedItems || []);
        setMissions(data.missions || []);
        setReminders(data.reminders || []);
        setConversations(data.conversations || []);
        setSearchHistory(data.searchHistory || []);
        setUserPreferences(data.preferences || {
          ollamaUrl: "http://localhost:11434",
          ollamaModel: "llama3.2",
          aiMode: "gemini",
          offlineMode: false,
          apiEndpoint: ""
        });
        setStats(data.stats);
      }
    } catch (err) {
      console.error("Failed to load SideQuest V2 database:", err);
      triggerNotification("Offline: using local browser storage fallback", "error");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();

    // Listen to actual network status
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const handlePullToRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  // Toast notification trigger
  const triggerNotification = (message: string, type: "success" | "info" | "error" = "success") => {
    setShowNotification({ message, type });
    setTimeout(() => setShowNotification(null), 4000);
  };

  // Post capture transaction
  const handleCapture = async (type: string, title: string, content: string, meta?: any, fileName?: string) => {
    try {
      const res = await fetch(getApiUrl("/api/capture"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, title, content, meta, fileName })
      });
      const data = await res.json();
      if (res.ok) {
        triggerNotification(`Captured ${type}: "${title || 'Clip'}"`, "success");
        setCapturedItems(prev => [data.item, ...prev]);
        setStats(data.stats);
        setShowCaptureModal(false);
        setActiveTab("dashboard");
      } else {
        triggerNotification(data.error || "Capture failure", "error");
      }
    } catch (err) {
      console.error("Capture transaction failed:", err);
      triggerNotification("Server synchronization error during capture", "error");
    }
  };

  // Run AI cognitive processing pipeline
  const handleAnalyze = async (id: string) => {
    try {
      const res = await fetch(getApiUrl(`/api/analyze/${id}`), {
        method: "POST"
      });
      const data = await res.json();
      if (res.ok) {
        triggerNotification("AI Cognitive parsing completed!", "success");
        setCapturedItems(prev => prev.map(item => item.id === id ? data.item : item));
        setMissions(data.mission ? [data.mission, ...missions] : missions);
        setReminders(data.reminders || reminders);
        setStats(data.stats);
      } else {
        triggerNotification(data.error || "Analysis failed", "error");
      }
    } catch (err) {
      console.error("AI pipeline trigger failed:", err);
      triggerNotification("AI pipeline endpoint timed out or failed", "error");
    }
  };

  // Toggle action checklists
  const handleToggleTask = async (missionId: string, taskId: string) => {
    try {
      const res = await fetch(getApiUrl("/api/tasks/toggle"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ missionId, taskId })
      });
      const data = await res.json();
      if (res.ok) {
        setMissions(data.missions);
        setStats(data.stats);
        
        // Match inside local capture lists
        setCapturedItems(prev => prev.map(item => {
          if (item.processed && item.analysis) {
            const updatedTasks = item.analysis.tasks.map(t => 
              t.id === taskId ? { ...t, status: t.status === "todo" ? "done" as const : "todo" as const } : t
            );
            return { ...item, analysis: { ...item.analysis, tasks: updatedTasks } };
          }
          return item;
        }));
      }
    } catch (err) {
      console.error("Task check failed:", err);
    }
  };

  // Toggle whole mission complete
  const handleToggleMission = async (missionId: string) => {
    try {
      const res = await fetch(getApiUrl("/api/missions/toggle"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ missionId })
      });
      const data = await res.json();
      if (res.ok) {
        setMissions(data.missions);
        setStats(data.stats);
        triggerNotification("Mission status updated", "info");
      }
    } catch (err) {
      console.error("Mission toggle failure:", err);
    }
  };

  // Toggle reminder snoozed or completed
  const handleToggleReminder = async (reminderId: string, status: "completed" | "snoozed" | "active") => {
    try {
      const res = await fetch(getApiUrl("/api/reminders/toggle"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reminderId, status })
      });
      const data = await res.json();
      if (res.ok) {
        setReminders(data.reminders);
        setStats(data.stats);
        triggerNotification(`Reminder marked as ${status}`, "info");
      }
    } catch (err) {
      console.error("Reminder check failed:", err);
    }
  };

  // Merge overlapping raw clips
  const handleMerge = async (sourceId: string, targetId: string) => {
    try {
      const res = await fetch(getApiUrl("/api/merge"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceId, targetId })
      });
      const data = await res.json();
      if (res.ok) {
        setCapturedItems(data.capturedItems);
        setStats(data.stats);
        triggerNotification("Captured nodes merged successfully", "success");
      }
    } catch (err) {
      console.error("Merge failure:", err);
    }
  };

  // Update server config preferences
  const handleSavePreferences = async (newPrefs: typeof userPreferences) => {
    try {
      const res = await fetch(getApiUrl("/api/preferences"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ preferences: newPrefs })
      });
      if (res.ok) {
        setUserPreferences(newPrefs);
        triggerNotification("Local preferences updated", "success");
      }
    } catch (err) {
      console.error("Save preferences failed:", err);
    }
  };

  // Reset database to completely empty state (Requirement 1 & 12)
  const handleResetDatabase = async () => {
    try {
      const res = await fetch(getApiUrl("/api/reset"), { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setCapturedItems([]);
        setMissions([]);
        setReminders([]);
        setConversations([]);
        setSearchHistory([]);
        setStats(data.stats);
        triggerNotification("Local database wiped successfully", "success");
        setActiveTab("dashboard");
      }
    } catch (err) {
      console.error("Reset failed:", err);
    }
  };

  // Promote a hidden intent directly into active checklists (V2 superpower)
  const handlePromoteIntent = (intent: any, sourceItemId: string) => {
    const linkedMission = missions.find(m => m.capturedItemIds.includes(sourceItemId));
    if (!linkedMission) {
      triggerNotification("No active mission corresponds to this source document.", "error");
      return;
    }

    const newTask = {
      id: `task-promoted-${Date.now()}`,
      title: `${intent.title}: ${intent.description.split(".")[0]}`,
      priority: intent.severity === "high" ? ("high" as const) : ("medium" as const),
      effort: "45 mins",
      dueDate: new Date().toISOString().split("T")[0],
      status: "todo" as const
    };

    setMissions(prev => prev.map(m => {
      if (m.id === linkedMission.id) {
        return {
          ...m,
          tasks: [...(m.tasks || []), newTask],
          hiddenIntentsCount: Math.max(0, m.hiddenIntentsCount - 1)
        };
      }
      return m;
    }));

    setStats(prev => ({
      ...prev,
      unfinishedIntentsCount: Math.max(0, prev.unfinishedIntentsCount - 1),
      score: Math.min(100, prev.score + 5)
    }));

    triggerNotification(`Promoted to "${linkedMission.title}" checklists`, "success");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center text-zinc-100">
        <div className="flex flex-col items-center gap-3 animate-pulse">
          <div className="w-10 h-10 rounded bg-blue-600 flex items-center justify-center font-bold text-white text-xl">
            S
          </div>
          <span className="text-xs font-mono tracking-widest text-zinc-400 uppercase">Loading Sandbox...</span>
        </div>
      </div>
    );
  }

  const isSimulatedOffline = userPreferences.offlineMode || isOffline;

  return (
    <div className="min-h-screen bg-zinc-900/60 flex items-center justify-center p-0 md:p-6 lg:p-8" id="sidequest-mobile-root">
      
      {/* Toast Alert */}
      {showNotification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 p-3 rounded-xl border text-xs font-semibold shadow-2xl flex items-center gap-2 bg-zinc-900 border-zinc-800 text-zinc-100 animate-bounce max-w-[90%] md:max-w-md">
          <Sparkles className={`w-4 h-4 shrink-0 ${showNotification.type === "success" ? "text-blue-400" : showNotification.type === "error" ? "text-red-400" : "text-amber-400"}`} />
          <span>{showNotification.message}</span>
        </div>
      )}

      {/* PHONE FRAME EMBED (Centered for Desktop reviews, 100% on Mobile) */}
      <div className="w-full max-w-[430px] h-screen md:h-[860px] bg-zinc-950 border-0 md:border-[6px] md:border-zinc-800 rounded-none md:rounded-[40px] shadow-2xl overflow-hidden flex flex-col relative">
        
        {/* TOP STATUS BAR (Native OS Feel) */}
        <div className="bg-zinc-950 px-5 pt-3 pb-1 flex justify-between items-center text-zinc-400 text-[10px] font-semibold select-none shrink-0">
          <span className="font-sans">03:01 UTC</span>
          
          {/* Simulated Dynamic Notch */}
          <div className="hidden md:block w-28 h-4 bg-black rounded-full absolute left-1/2 -translate-x-1/2 top-1.5" />

          <div className="flex items-center gap-1.5">
            {isSimulatedOffline ? (
              <span className="text-red-400 font-mono text-[9px] uppercase font-extrabold flex items-center gap-0.5">
                Offline
              </span>
            ) : (
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <Battery className="w-3.5 h-3.5 text-zinc-300" />
          </div>
        </div>

        {/* OFFLINE BANNER */}
        {isSimulatedOffline && (
          <div className="bg-red-950/45 text-red-400 px-3 py-1 text-center text-[10px] font-mono font-bold tracking-widest border-b border-red-900/40 shrink-0">
            LOCAL ENGINE RUNNING • OFFLINE
          </div>
        )}

        {/* MAIN BODY AREA WITH OVERFLOW ACCELERATED */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col pb-20">
          
          {/* Dashboard View */}
          {activeTab === "dashboard" && (
            <Dashboard 
              stats={stats}
              missions={missions}
              reminders={reminders}
              capturedItems={capturedItems}
              onAnalyze={handleAnalyze}
              onToggleTask={handleToggleTask}
              onToggleReminder={handleToggleReminder}
              onSelectTab={setActiveTab}
              onRefresh={handlePullToRefresh}
              refreshing={refreshing}
            />
          )}

          {/* Missions Checklist View */}
          {activeTab === "missions" && (
            <MissionsBoard 
              missions={missions}
              capturedItems={capturedItems}
              onToggleTask={handleToggleTask}
              onToggleMission={handleToggleMission}
              onPromoteIntent={handlePromoteIntent}
            />
          )}

          {/* Knowledge base / Cognitive QA chat */}
          {activeTab === "knowledge" && (
            <KnowledgeBase 
              capturedItems={capturedItems}
              conversations={conversations}
              searchHistory={searchHistory}
              preferences={userPreferences}
              onSetConversations={setConversations}
              getApiUrl={getApiUrl}
            />
          )}

          {/* Settings and System reset */}
          {activeTab === "settings" && (
            <SettingsScreen 
              preferences={userPreferences}
              onSavePreferences={handleSavePreferences}
              onReset={handleResetDatabase}
            />
          )}

        </div>

        {/* CAPTURE FAB BUTTON (Notion Mobile Center) */}
        <button
          onClick={() => setShowCaptureModal(true)}
          className="absolute bottom-16 left-1/2 -translate-x-1/2 z-40 w-14 h-14 bg-blue-600 hover:bg-blue-500 rounded-full flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all text-white border-4 border-zinc-950 cursor-pointer"
          title="Quick Capture Center"
        >
          <Plus className="w-6 h-6" />
        </button>

        {/* BOTTOM TAB NAVIGATION BAR (Notion / Keep Mobile style) */}
        <nav className="absolute bottom-0 left-0 right-0 h-16 bg-zinc-950/95 backdrop-blur-md border-t border-zinc-900 flex justify-around items-center px-4 z-30 select-none">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors ${activeTab === "dashboard" ? "text-blue-400" : "text-zinc-500 hover:text-zinc-300"}`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[9px] font-medium font-sans">Home</span>
          </button>

          <button
            onClick={() => setActiveTab("missions")}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors mr-8 ${activeTab === "missions" ? "text-blue-400" : "text-zinc-500 hover:text-zinc-300"}`}
          >
            <Target className="w-5 h-5" />
            <span className="text-[9px] font-medium font-sans">Missions</span>
          </button>

          <button
            onClick={() => setActiveTab("knowledge")}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors ml-8 ${activeTab === "knowledge" ? "text-blue-400" : "text-zinc-500 hover:text-zinc-300"}`}
          >
            <Search className="w-5 h-5" />
            <span className="text-[9px] font-medium font-sans">Brain</span>
          </button>

          <button
            onClick={() => setActiveTab("settings")}
            className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors ${activeTab === "settings" ? "text-blue-400" : "text-zinc-500 hover:text-zinc-300"}`}
          >
            <Settings className="w-5 h-5" />
            <span className="text-[9px] font-medium font-sans">System</span>
          </button>
        </nav>

        {/* FULL SCREEN QUICK CAPTURE MODAL (Arc Search Mobile UI style) */}
        {showCaptureModal && (
          <CaptureWorkspace 
            onCapture={handleCapture}
            onClose={() => setShowCaptureModal(false)}
          />
        )}

      </div>

    </div>
  );
}
