import React from "react";
import { 
  Zap, 
  Target, 
  Bell, 
  AlertTriangle, 
  Cpu, 
  RefreshCw, 
  Sparkles, 
  ChevronRight, 
  FileText,
  Mic,
  Link,
  Image,
  Play
} from "lucide-react";
import { ProductivityStats, CapturedItem, Mission, SmartReminder } from "../types";

interface DashboardProps {
  stats: ProductivityStats;
  missions: Mission[];
  reminders: SmartReminder[];
  capturedItems: CapturedItem[];
  onAnalyze: (id: string) => void;
  onToggleTask: (missionId: string, taskId: string) => void;
  onToggleReminder: (reminderId: string, status: "completed" | "snoozed" | "active") => void;
  onSelectTab: (tab: string) => void;
  onRefresh: () => void;
  refreshing: boolean;
}

export default function Dashboard({
  stats,
  missions,
  reminders,
  capturedItems,
  onAnalyze,
  onToggleTask,
  onToggleReminder,
  onSelectTab,
  onRefresh,
  refreshing
}: DashboardProps) {
  const unprocessedItems = capturedItems.filter(i => !i.processed);
  const activeReminders = reminders.filter(r => r.status === "active");

  return (
    <div className="p-4 space-y-5 flex-1 flex flex-col min-w-0" id="screen-dashboard">
      
      {/* Top Welcome Title */}
      <div className="flex justify-between items-center shrink-0">
        <div>
          <h1 className="text-lg font-bold text-zinc-100 font-sans tracking-tight">
            My Workspace
          </h1>
          <p className="text-[10px] text-zinc-500 font-mono">
            SideQuest Autonomous Core
          </p>
        </div>
        
        <button 
          onClick={onRefresh}
          className={`p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200 cursor-pointer ${refreshing ? "animate-spin" : ""}`}
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* METRICS GRID (No Fake Data, Entirely Derived) */}
      <div className="grid grid-cols-2 gap-3 shrink-0">
        
        {/* Core Score Gauge */}
        <div className="p-3.5 bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800/80 rounded-2xl flex flex-col justify-between h-24">
          <span className="text-[9px] font-bold font-mono text-zinc-400 uppercase tracking-widest block">
            System Score
          </span>
          <div>
            <span className="text-2xl font-bold font-sans tracking-tight text-blue-400">
              {stats.score}%
            </span>
            <div className="w-full bg-zinc-800/50 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div 
                className="bg-blue-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${stats.score}%` }} 
              />
            </div>
          </div>
        </div>

        {/* Streak & Productivity Weight */}
        <div className="p-3.5 bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800/80 rounded-2xl flex flex-col justify-between h-24">
          <span className="text-[9px] font-bold font-mono text-zinc-400 uppercase tracking-widest block">
            Current Streak
          </span>
          <div>
            <span className="text-2xl font-bold font-sans text-amber-500 tracking-tight flex items-baseline gap-1">
              {stats.streakDays} <span className="text-[10px] text-zinc-500 font-mono uppercase">Days</span>
            </span>
            <p className="text-[9px] text-zinc-500 font-mono mt-1">
              Active local inputs
            </p>
          </div>
        </div>

        {/* Captured Items metric */}
        <div className="p-3.5 bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800/80 rounded-2xl flex flex-col justify-between h-20">
          <span className="text-[9px] font-bold font-mono text-zinc-500 uppercase tracking-wider block">
            Imports Indexed
          </span>
          <span className="text-xl font-bold text-zinc-200">
            {stats.capturedCount} <span className="text-[9px] text-zinc-500 font-normal">nodes</span>
          </span>
        </div>

        {/* At Risk/Action count */}
        <div className="p-3.5 bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800/80 rounded-2xl flex flex-col justify-between h-20">
          <span className="text-[9px] font-bold font-mono text-red-400 uppercase tracking-wider block">
            Tasks At Risk
          </span>
          <span className="text-xl font-bold text-red-400">
            {stats.tasksAtRiskCount} <span className="text-[9px] text-zinc-500 font-normal">items</span>
          </span>
        </div>

      </div>

      {/* EMPTY STATES FOR THE APP (Requirement 1 & 11) */}
      {capturedItems.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4">
          <div className="w-16 h-16 rounded-full bg-zinc-900/60 border border-zinc-800 flex items-center justify-center text-zinc-600">
            <Cpu className="w-8 h-8" />
          </div>
          <div className="space-y-1.5">
            <h3 className="text-sm font-bold text-zinc-300">Your Sandbox is Empty</h3>
            <p className="text-xs text-zinc-500 leading-relaxed max-w-xs">
              No hardcoded mock datasets exist here. Touch the center <span className="text-blue-400 font-bold">+</span> button below to import notes, screenshots, clipboard dumps, or record actual voice clips.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-5 flex-1 overflow-y-auto pr-0.5">

          {/* ACTIVE SMART REMINDERS / ALERTS */}
          {activeReminders.length > 0 && (
            <div className="space-y-2 shrink-0">
              <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1">
                <Bell className="w-3.5 h-3.5 text-blue-400" />
                Reminders & Alerts
              </span>
              <div className="space-y-2">
                {activeReminders.map(rem => (
                  <div 
                    key={rem.id} 
                    className="p-3 rounded-xl border border-blue-950/40 bg-blue-950/5 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <span className="text-xs text-zinc-300 block leading-tight font-sans">
                        {rem.message}
                      </span>
                      <span className="text-[9px] text-blue-400 font-mono">
                        Nudge: {rem.triggerTime}
                      </span>
                    </div>
                    <button
                      onClick={() => onToggleReminder(rem.id, "completed")}
                      className="px-2.5 py-1 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/10 rounded-lg text-[10px] font-bold shrink-0 cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* UNPROCESSED RAW IMPORTS */}
          {unprocessedItems.length > 0 && (
            <div className="space-y-2">
              <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                Pending Cognitive Analysis ({unprocessedItems.length})
              </span>
              <div className="space-y-2">
                {unprocessedItems.map(item => {
                  return (
                    <div 
                      key={item.id} 
                      className="p-3 rounded-xl border border-zinc-800 bg-zinc-900/30 flex items-center justify-between gap-3"
                    >
                      <div className="flex gap-2.5 items-center min-w-0">
                        {item.type === "voice" && <Mic className="w-4 h-4 text-blue-400 shrink-0" />}
                        {item.type === "image" && <Image className="w-4 h-4 text-emerald-400 shrink-0" />}
                        {item.type === "link" && <Link className="w-4 h-4 text-purple-400 shrink-0" />}
                        {(item.type !== "voice" && item.type !== "image" && item.type !== "link") && <FileText className="w-4 h-4 text-zinc-400 shrink-0" />}
                        
                        <div className="min-w-0">
                          <span className="text-xs font-semibold text-zinc-200 block truncate">
                            {item.title}
                          </span>
                          <span className="text-[9px] text-zinc-500 font-mono">
                            {new Date(item.createdAt).toLocaleDateString()} • {item.type.toUpperCase()}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => onAnalyze(item.id)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[10px] font-bold shrink-0 cursor-pointer shadow-md shadow-blue-900/20"
                      >
                        <Play className="w-2.5 h-2.5 fill-current" />
                        Analyze
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* COMPLETED PROCESSED CHANNELS */}
          {capturedItems.filter(i => i.processed).length > 0 && (
            <div className="space-y-2">
              <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest block">
                Processed Archives
              </span>
              <div className="space-y-2">
                {capturedItems.filter(i => i.processed).map(item => (
                  <div 
                    key={item.id}
                    onClick={() => onSelectTab("missions")}
                    className="p-3 rounded-xl border border-zinc-900 bg-zinc-950/40 hover:border-zinc-800 transition-colors cursor-pointer flex justify-between items-center"
                  >
                    <div className="min-w-0">
                      <span className="text-xs font-semibold text-zinc-300 block truncate">
                        {item.title}
                      </span>
                      <p className="text-[10px] text-zinc-500 leading-normal truncate max-w-[280px]">
                        {item.analysis?.summary}
                      </p>
                      <div className="flex gap-2 mt-1 items-center">
                        <span className="px-1.5 py-0.2 rounded text-[8px] bg-zinc-900 text-zinc-400 font-mono uppercase">
                          {item.analysis?.category}
                        </span>
                        <span className="text-[9px] font-mono text-emerald-400">
                          Confidence: {item.analysis?.confidenceScore}%
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-zinc-600 shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
