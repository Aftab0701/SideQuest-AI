import React, { useState, useEffect, useRef } from "react";
import { 
  Search, 
  MessageSquare, 
  BookOpen, 
  ChevronRight, 
  Cpu, 
  Send, 
  History, 
  User, 
  FileText,
  Bookmark,
  TrendingUp,
  FolderLock
} from "lucide-react";
import { CapturedItem, ChatConversation, ChatMessage, UserPreferences } from "../types";

interface KnowledgeBaseProps {
  capturedItems: CapturedItem[];
  conversations: ChatConversation[];
  searchHistory: string[];
  preferences: UserPreferences;
  onSetConversations: (convs: ChatConversation[]) => void;
  getApiUrl: (path: string) => string;
}

export default function KnowledgeBase({
  capturedItems,
  conversations,
  searchHistory,
  preferences,
  onSetConversations,
  getApiUrl
}: KnowledgeBaseProps) {
  const [activeTab, setActiveTab] = useState<"search" | "chat">("search");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [searchResults, setSearchResults] = useState<{ item: CapturedItem; score: number }[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  // Chat states
  const [chatQuery, setChatQuery] = useState<string>("");
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [sendingMsg, setSendingMsg] = useState<boolean>(false);
  
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll to chat bottoms
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [conversations, activeConversationId, sendingMsg]);

  // Run real-time backend keyword / semantic search
  const handleRunSearch = async (queryStr: string) => {
    if (!queryStr.trim()) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    try {
      const res = await fetch(getApiUrl("/api/search"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: queryStr })
      });
      const data = await res.json();
      if (res.ok) {
        setSearchResults(data.results || []);
      }
    } catch (err) {
      console.error("Search failed:", err);
    } finally {
      setIsSearching(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      handleRunSearch(searchQuery);
    }, 350);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Submit chat prompt to RAG endpoint (Requirement 6)
  const handleSendChat = async () => {
    if (!chatQuery.trim() || sendingMsg) return;

    const userText = chatQuery;
    setChatQuery("");
    setSendingMsg(true);

    const targetConvId = activeConversationId || `chat-${Date.now()}`;
    if (!activeConversationId) {
      setActiveConversationId(targetConvId);
    }

    try {
      const res = await fetch(getApiUrl("/api/chat"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: targetConvId, text: userText })
      });
      const data = await res.json();
      if (res.ok) {
        // Sync conversation lists
        const updatedConversations = conversations.some(c => c.id === targetConvId)
          ? conversations.map(c => c.id === targetConvId ? data.conversation : c)
          : [data.conversation, ...conversations];
        onSetConversations(updatedConversations);
      }
    } catch (err) {
      console.error("Knowledge base chat failed:", err);
    } finally {
      setSendingMsg(false);
    }
  };

  const activeConv = conversations.find(c => c.id === activeConversationId);

  // Suggested questions based on real user datasets (Requirement 1 & 12)
  const SUGGESTED_PROMPTS = [
    "What deadlines do I have?",
    "What startup ideas have I written?",
    "What commitments have I forgotten?"
  ];

  return (
    <div className="p-4 space-y-4 flex-1 flex flex-col min-w-0 h-full" id="screen-knowledge">
      
      {/* Top Header */}
      <div className="shrink-0">
        <h1 className="text-lg font-bold text-zinc-100 font-sans tracking-tight">
          Knowledge Brain
        </h1>
        <p className="text-[10px] text-zinc-500 font-mono">
          RAG-indexed semantic querying & vector search
        </p>
      </div>

      {/* Mode selectors */}
      <div className="flex bg-zinc-950 border border-zinc-900 rounded-xl p-1 shrink-0 select-none">
        <button
          onClick={() => setActiveTab("search")}
          className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "search" ? "bg-blue-600 text-white" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          Search Index
        </button>
        <button
          onClick={() => setActiveTab("chat")}
          className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "chat" ? "bg-blue-600 text-white" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          AI Consult Chat
        </button>
      </div>

      {/* TAB CONTENT MODULES */}
      <div className="flex-1 flex flex-col min-h-0">
        
        {/* TAB 1: SEMANTIC DOCUMENT SEARCH */}
        {activeTab === "search" && (
          <div className="flex-1 flex flex-col min-h-0 space-y-3">
            
            {/* Search Input bar */}
            <div className="relative shrink-0">
              <Search className="w-4 h-4 text-zinc-600 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search raw captures, documents, files..."
                className="w-full bg-zinc-950 border border-zinc-900 rounded-xl pl-9 pr-4 py-2 text-xs text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* SEARCH RESULTS SCROLLER */}
            <div className="flex-1 overflow-y-auto pr-0.5 space-y-2.5">
              {searchQuery.trim() === "" ? (
                /* Static view if no query typed */
                <div className="space-y-4">
                  {searchHistory.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-wider block">
                        Recent Searches
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {searchHistory.map((hist, idx) => (
                          <button
                            key={idx}
                            onClick={() => setSearchQuery(hist)}
                            className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800 text-[9px] text-zinc-400 hover:text-zinc-200 font-mono cursor-pointer"
                          >
                            {hist}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="p-4 rounded-xl border border-zinc-900 bg-zinc-950/20 space-y-2">
                    <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest flex items-center gap-1">
                      <FolderLock className="w-3.5 h-3.5 text-blue-400" /> Grounded Search Engine
                    </span>
                    <p className="text-[10px] text-zinc-500 leading-relaxed">
                      Every processed document is cataloged and vectorized. Use search phrases to instantly recall coordinates, contact numbers, server logs, or pricing tiers.
                    </p>
                  </div>
                </div>
              ) : isSearching ? (
                <div className="text-center py-10 text-zinc-500 font-mono text-xs">
                  Querying vector embeddings...
                </div>
              ) : searchResults.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 font-mono text-xs">
                  No matches located inside the local knowledge cache.
                </div>
              ) : (
                searchResults.map(({ item, score }) => (
                  <div 
                    key={item.id}
                    className="p-3 bg-zinc-950/40 border border-zinc-900 rounded-xl space-y-1.5 hover:border-zinc-800 transition-colors"
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] text-zinc-500 font-mono uppercase tracking-wide">
                        {item.type} • {new Date(item.createdAt).toLocaleDateString()}
                      </span>
                      <span className="text-[9px] font-mono text-blue-400 font-bold bg-blue-950/20 px-1.5 py-0.2 rounded border border-blue-900/10">
                        Match Score: {Math.round(score * 100)}%
                      </span>
                    </div>
                    <span className="text-xs font-semibold text-zinc-200 block truncate">
                      {item.title}
                    </span>
                    <p className="text-[10px] text-zinc-400 leading-snug line-clamp-3 bg-zinc-950/50 p-2 rounded font-sans whitespace-pre-wrap">
                      {item.content}
                    </p>
                  </div>
                ))
              )}
            </div>

          </div>
        )}

        {/* TAB 2: AI CONSULT CHAT (RAG QUESTION-ANSWERING) */}
        {activeTab === "chat" && (
          <div className="flex-1 flex flex-col min-h-0 space-y-3">
            
            {/* Conversation Messages area */}
            <div className="flex-1 overflow-y-auto pr-0.5 space-y-3 bg-zinc-950/30 border border-zinc-900 rounded-xl p-3 flex flex-col justify-start">
              
              {!activeConversationId && (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-4 space-y-4">
                  <div className="w-12 h-12 rounded-full bg-zinc-900/60 border border-zinc-800 flex items-center justify-center text-zinc-500">
                    <Cpu className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-zinc-300 block">Consult the local knowledge brain</span>
                    <p className="text-[10px] text-zinc-500 leading-relaxed max-w-[250px] mx-auto">
                      Ask any questions. The AI will answer utilizing only your processed source documents context.
                    </p>
                  </div>

                  {/* Suggestion Prompts */}
                  <div className="w-full space-y-1.5 pt-2">
                    {SUGGESTED_PROMPTS.map((pr, idx) => (
                      <button
                        key={idx}
                        onClick={() => setChatQuery(pr)}
                        className="w-full text-left p-2.5 rounded-lg border border-zinc-900 bg-zinc-950 hover:bg-zinc-900 text-[10px] text-zinc-400 hover:text-zinc-200 transition-colors flex items-center justify-between cursor-pointer"
                      >
                        <span>{pr}</span>
                        <ChevronRight className="w-3 h-3 text-zinc-600" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Chat Thread */}
              {activeConv && activeConv.messages.map((msg) => {
                const isUser = msg.sender === "user";
                return (
                  <div 
                    key={msg.id}
                    className={`flex gap-2.5 items-start max-w-[85%] ${isUser ? "self-end flex-row-reverse" : "self-start"}`}
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${isUser ? "bg-blue-600 text-white" : "bg-zinc-800 text-zinc-300"}`}>
                      {isUser ? <User className="w-3.5 h-3.5" /> : <Cpu className="w-3.5 h-3.5" />}
                    </div>

                    <div className="space-y-1">
                      <div className={`p-2.5 rounded-2xl text-[11px] leading-relaxed ${isUser ? "bg-blue-600 text-white" : "bg-zinc-900 text-zinc-300 border border-zinc-800/80"}`}>
                        {msg.text}
                      </div>
                      
                      {/* CITED SOURCES */}
                      {!isUser && msg.sources && msg.sources.length > 0 && (
                        <div className="flex flex-wrap gap-1 items-center pt-0.5">
                          <span className="text-[8px] font-mono text-zinc-500 font-bold">Citations:</span>
                          {msg.sources.map(src => (
                            <span 
                              key={src.id}
                              className="text-[8px] font-mono px-1 py-0.2 bg-zinc-900 text-zinc-400 rounded border border-zinc-800"
                            >
                              {src.title}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {sendingMsg && (
                <div className="self-start flex gap-2.5 items-center max-w-[85%] animate-pulse">
                  <div className="w-6 h-6 rounded-full bg-zinc-800 flex items-center justify-center">
                    <Cpu className="w-3.5 h-3.5 text-zinc-500" />
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500">Querying local engine...</span>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Chat Input form */}
            <div className="relative shrink-0 flex gap-2">
              <input
                type="text"
                value={chatQuery}
                onChange={e => setChatQuery(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSendChat()}
                placeholder="Ask local brain..."
                className="flex-1 bg-zinc-950 border border-zinc-900 rounded-xl px-3.5 py-2.5 text-xs text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleSendChat}
                disabled={!chatQuery.trim() || sendingMsg}
                className="p-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl disabled:opacity-50 disabled:pointer-events-none transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
