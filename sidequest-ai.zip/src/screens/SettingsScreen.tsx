import React, { useState } from "react";
import { 
  Settings, 
  Cpu, 
  RotateCcw, 
  Database, 
  Network, 
  AlertTriangle,
  Flame,
  Info
} from "lucide-react";
import { UserPreferences } from "../types";

interface SettingsScreenProps {
  preferences: UserPreferences;
  onSavePreferences: (newPrefs: UserPreferences) => void;
  onReset: () => void;
}

export default function SettingsScreen({
  preferences,
  onSavePreferences,
  onReset
}: SettingsScreenProps) {
  const [url, setUrl] = useState<string>(preferences.ollamaUrl);
  const [model, setModel] = useState<string>(preferences.ollamaModel);
  const [mode, setMode] = useState<"local" | "gemini" | "hybrid">(preferences.aiMode);
  const [offlineSim, setOfflineSim] = useState<boolean>(preferences.offlineMode);
  const [apiEndpoint, setApiEndpoint] = useState<string>(preferences.apiEndpoint || "");

  const handleSave = () => {
    onSavePreferences({
      ollamaUrl: url,
      ollamaModel: model,
      aiMode: mode,
      offlineMode: offlineSim,
      apiEndpoint: apiEndpoint
    });
  };

  const MODELS = [
    { id: "llama3.2", label: "llama3.2 (3B - Default)" },
    { id: "gemma3", label: "gemma3 (4B)" },
    { id: "qwen2.5", label: "qwen2.5 (1.5B/7B)" },
    { id: "mistral", label: "mistral (7B)" },
    { id: "phi4", label: "phi4 (14B)" }
  ];

  return (
    <div className="p-4 space-y-4 flex-1 flex flex-col min-w-0 h-full" id="screen-settings">
      
      {/* Top Header */}
      <div className="shrink-0">
        <h1 className="text-lg font-bold text-zinc-100 font-sans tracking-tight">
          System Console
        </h1>
        <p className="text-[10px] text-zinc-500 font-mono">
          Ollama model registries & sandbox configuration
        </p>
      </div>

      <div className="flex-1 overflow-y-auto pr-0.5 space-y-4">
        
        {/* SECTION 1: AI COGNITIVE PARSING MODE */}
        <div className="p-3.5 rounded-xl border border-zinc-900 bg-zinc-950/40 space-y-3">
          <span className="text-[9px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
            AI Execution Router
          </span>

          <div className="space-y-2">
            <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
              Routing Engine Strategy
            </label>
            <div className="grid grid-cols-3 gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-900">
              {[
                { id: "gemini", label: "Gemini Cloud" },
                { id: "local", label: "Local Ollama" },
                { id: "hybrid", label: "Hybrid Core" }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => setMode(opt.id as any)}
                  className={`py-1 text-[9px] font-bold rounded transition-all cursor-pointer ${
                    mode === opt.id ? "bg-blue-600 text-white shadow" : "text-zinc-500 hover:text-zinc-300"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <p className="text-[9px] text-zinc-500 leading-normal leading-relaxed mt-1">
              **Hybrid Core** tries local Ollama endpoints first and falls back to server-side Gemini 3.5-Flash automatically to prevent timeouts or service blocking.
            </p>
          </div>
        </div>

        {/* SECTION 2: OLLAMA CONFIGURATION */}
        <div className="p-3.5 rounded-xl border border-zinc-900 bg-zinc-950/40 space-y-3">
          <span className="text-[9px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1.5">
            <Network className="w-3.5 h-3.5 text-amber-500" />
            Ollama REST Parameters
          </span>

          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
                Ollama Host API Address
              </label>
              <input
                type="text"
                value={url}
                onChange={e => setUrl(e.target.value)}
                placeholder="http://localhost:11434"
                className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
                Select Model Registry
              </label>
              <select
                value={model}
                onChange={e => setModel(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2 text-xs text-zinc-350 focus:outline-none focus:border-blue-500 font-mono"
              >
                {MODELS.map(m => (
                  <option key={m.id} value={m.id}>{m.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* SECTION 2.5: SERVER SYNCHRONIZATION ENDPOINT (APK COMPATIBILITY) */}
        <div className="p-3.5 rounded-xl border border-zinc-900 bg-zinc-950/40 space-y-3">
          <span className="text-[9px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-blue-400" />
            SideQuest Cloud API Sync
          </span>

          <div className="space-y-1">
            <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
              Hosted Server Endpoint
            </label>
            <input
              type="text"
              value={apiEndpoint}
              onChange={e => setApiEndpoint(e.target.value)}
              placeholder="https://ais-dev-lv6rkcyvurlp2lmi6qdqz7-404080228449.asia-southeast1.run.app"
              className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none focus:border-blue-500 font-mono"
            />
            <p className="text-[9px] text-zinc-500 leading-normal leading-relaxed pt-1">
              Specify the API Server URL when running as a mobile APK, so that the mobile app can sync with the Cloud database server seamlessly.
            </p>
          </div>
        </div>

        {/* SECTION 3: SYSTEM OFFLINE & ACCESSIBILITY */}
        <div className="p-3.5 rounded-xl border border-zinc-900 bg-zinc-950/40 space-y-3">
          <span className="text-[9px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-emerald-400" />
            Reliability & Offline Mode
          </span>

          <div className="flex items-center justify-between border-b border-zinc-900/50 pb-2">
            <div>
              <span className="text-xs font-semibold text-zinc-300 block">Simulate Offline Mode</span>
              <span className="text-[9px] text-zinc-500 font-mono">Disables outward network pings</span>
            </div>
            <input
              type="checkbox"
              checked={offlineSim}
              onChange={e => setOfflineSim(e.target.checked)}
              className="w-4 h-4 rounded text-blue-500 bg-zinc-950 accent-blue-500 cursor-pointer"
            />
          </div>

          <div className="p-2.5 rounded bg-zinc-900/30 border border-zinc-900 text-[9px] text-zinc-500 leading-normal leading-relaxed flex gap-2">
            <Info className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
            <span>
              Offline Mode simulation forces index queries, task checklist saves, and OCR models to process using fully client-side cache, matching actual native App capabilities.
            </span>
          </div>
        </div>

        {/* SECTION 4: SAVE ACTION */}
        <button
          onClick={handleSave}
          className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
        >
          Save Configuration
        </button>

        {/* SECTION 5: DESTRUCTIVE CLEAR DATABASE */}
        <div className="p-3.5 rounded-xl border border-red-950/30 bg-red-950/5 space-y-3.5">
          <span className="text-[9px] font-mono font-bold text-red-400 uppercase tracking-widest flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            System Administration
          </span>

          <div className="space-y-1">
            <span className="text-xs font-semibold text-zinc-300 block">Wipe Local Database</span>
            <p className="text-[10px] text-zinc-500 leading-normal leading-relaxed">
              Completely wipes out any saved documents, checklist histories, search histories, and RAG chats. Recommended for resetting sandbox audits.
            </p>
          </div>

          <button
            onClick={() => {
              if (window.confirm("Are you absolutely sure you want to clear your local knowledge database? This cannot be undone.")) {
                onReset();
              }
            }}
            className="w-full py-2 bg-red-950/35 hover:bg-red-950/50 text-red-400 border border-red-900/35 hover:border-red-900/50 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 inline mr-1.5" /> Wipe & Re-seed State
          </button>
        </div>

      </div>

    </div>
  );
}
