import React, { useState } from "react";
import { 
  Target, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  ChevronDown, 
  ChevronUp, 
  Sparkles,
  Inbox,
  ArrowRight
} from "lucide-react";
import { Mission, CapturedItem } from "../types";

interface MissionsBoardProps {
  missions: Mission[];
  capturedItems: CapturedItem[];
  onToggleTask: (missionId: string, taskId: string) => void;
  onToggleMission: (missionId: string) => void;
  onPromoteIntent: (intent: any, sourceItemId: string) => void;
}

export default function MissionsBoard({
  missions,
  capturedItems,
  onToggleTask,
  onToggleMission,
  onPromoteIntent
}: MissionsBoardProps) {
  const [filter, setFilter] = useState<"active" | "completed" | "intents">("active");
  const [expandedMissionId, setExpandedMissionId] = useState<string | null>(null);

  // Filter missions
  const activeMissions = missions.filter(m => m.status !== "completed");
  const completedMissions = missions.filter(m => m.status === "completed");

  // Collect all hidden intents across all documents
  const allHiddenIntents: { intent: any; item: CapturedItem }[] = [];
  capturedItems.forEach(item => {
    if (item.processed && item.analysis?.hiddenIntents) {
      item.analysis.hiddenIntents.forEach(intent => {
        allHiddenIntents.push({ intent, item });
      });
    }
  });

  const toggleMissionExpansion = (id: string) => {
    setExpandedMissionId(expandedMissionId === id ? null : id);
  };

  return (
    <div className="p-4 space-y-4 flex-1 flex flex-col min-w-0" id="screen-missions">
      
      {/* Top Header */}
      <div className="shrink-0">
        <h1 className="text-lg font-bold text-zinc-100 font-sans tracking-tight">
          Execution Board
        </h1>
        <p className="text-[10px] text-zinc-500 font-mono">
          Convert messy streams into actionable checklists
        </p>
      </div>

      {/* FILTER TABS */}
      <div className="flex bg-zinc-950 border border-zinc-900 rounded-xl p-1 select-none shrink-0">
        <button
          onClick={() => setFilter("active")}
          className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg transition-all cursor-pointer ${
            filter === "active" ? "bg-blue-600 text-white" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Active ({activeMissions.length})
        </button>
        <button
          onClick={() => setFilter("completed")}
          className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg transition-all cursor-pointer ${
            filter === "completed" ? "bg-blue-600 text-white" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Completed ({completedMissions.length})
        </button>
        <button
          onClick={() => setFilter("intents")}
          className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg transition-all cursor-pointer ${
            filter === "intents" ? "bg-blue-600 text-white" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Intents ({allHiddenIntents.length})
        </button>
      </div>

      {/* LIST CONTENT AREA */}
      <div className="flex-1 overflow-y-auto pr-0.5 space-y-3">
        
        {/* ACTIVE / PLANNING COHORT */}
        {filter === "active" && (
          activeMissions.length === 0 ? (
            <div className="py-12 text-center text-zinc-500 font-mono text-xs flex flex-col items-center justify-center space-y-3">
              <Target className="w-10 h-10 text-zinc-700" />
              <span>No active missions at this time. Analyze fresh fragments first!</span>
            </div>
          ) : (
            activeMissions.map(m => {
              const isExpanded = expandedMissionId === m.id;
              const totalTasks = m.tasks ? m.tasks.length : 0;
              const completedTasks = m.tasks ? m.tasks.filter(t => t.status === "done").length : 0;
              const pct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

              return (
                <div 
                  key={m.id} 
                  className="rounded-xl border border-zinc-900 bg-zinc-950/50 p-3.5 space-y-3"
                >
                  <div 
                    onClick={() => toggleMissionExpansion(m.id)}
                    className="flex justify-between items-start gap-2.5 cursor-pointer"
                  >
                    <div className="min-w-0 flex-1">
                      <span className="px-1.5 py-0.2 rounded text-[8px] font-mono bg-zinc-900 text-zinc-400 uppercase tracking-wider block w-fit mb-1.5">
                        {m.category}
                      </span>
                      <span className="text-xs font-bold text-zinc-100 block tracking-tight leading-snug">
                        {m.title}
                      </span>
                      <p className="text-[10px] text-zinc-500 mt-1 leading-snug line-clamp-2">
                        {m.description}
                      </p>
                    </div>
                    <div className="shrink-0 pt-0.5">
                      {isExpanded ? <ChevronUp className="w-4 h-4 text-zinc-500" /> : <ChevronDown className="w-4 h-4 text-zinc-500" />}
                    </div>
                  </div>

                  {/* Progress gauge */}
                  <div className="flex items-center justify-between text-[9px] font-mono text-zinc-500 border-t border-zinc-900/40 pt-2.5">
                    <span>Tasks: {completedTasks}/{totalTasks}</span>
                    <span className="font-bold text-blue-400">{pct}%</span>
                  </div>
                  <div className="w-full bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-blue-500 h-full rounded-full transition-all duration-350" style={{ width: `${pct}%` }} />
                  </div>

                  {/* Expanded Task Checklist */}
                  {isExpanded && m.tasks && (
                    <div className="space-y-2 pt-2.5 border-t border-zinc-900">
                      {m.tasks.map(task => (
                        <div 
                          key={task.id}
                          className="flex items-start gap-2.5 p-2 bg-zinc-900/30 rounded-lg border border-zinc-900/80"
                        >
                          <input
                            type="checkbox"
                            checked={task.status === "done"}
                            onChange={() => onToggleTask(m.id, task.id)}
                            className="w-4 h-4 mt-0.5 border-zinc-800 rounded text-blue-500 focus:ring-0 focus:ring-offset-0 bg-zinc-950 accent-blue-500 cursor-pointer"
                          />
                          <div className="min-w-0 flex-1">
                            <span className={`text-[11px] block leading-tight font-sans ${task.status === "done" ? "line-through text-zinc-600" : "text-zinc-300"}`}>
                              {task.title}
                            </span>
                            <div className="flex gap-2 items-center mt-1">
                              <span className={`text-[8px] font-mono px-1 rounded uppercase font-bold ${
                                task.priority === "urgent" ? "bg-red-950/50 text-red-400 border border-red-900/20" :
                                task.priority === "high" ? "bg-orange-950/50 text-orange-400" : "bg-zinc-900 text-zinc-500"
                              }`}>
                                {task.priority}
                              </span>
                              <span className="text-[8px] font-mono text-zinc-500">Effort: {task.effort}</span>
                              <span className="text-[8px] font-mono text-zinc-500">Due: {task.dueDate}</span>
                            </div>
                          </div>
                        </div>
                      ))}

                      {/* Complete Mission CTA */}
                      {pct === 100 && (
                        <button
                          onClick={() => onToggleMission(m.id)}
                          className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-emerald-600 hover:bg-emerald-550 text-white rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          Complete Mission (+{m.productivityWeight} PTS)
                        </button>
                      )}
                    </div>
                  )}

                </div>
              );
            })
          )
        )}

        {/* COMPLETED COHORT */}
        {filter === "completed" && (
          completedMissions.length === 0 ? (
            <div className="py-12 text-center text-zinc-500 font-mono text-xs">
              No completed missions logged yet.
            </div>
          ) : (
            completedMissions.map(m => (
              <div 
                key={m.id} 
                className="p-3 bg-zinc-950/20 border border-zinc-900 rounded-xl flex items-center justify-between"
              >
                <div>
                  <span className="text-xs font-bold text-zinc-400 block line-through">{m.title}</span>
                  <span className="text-[9px] text-zinc-600 font-mono block">Finished: {new Date().toLocaleDateString()}</span>
                </div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/10 px-2 py-0.5 rounded border border-emerald-900/10">
                  +{m.productivityWeight} PTS
                </span>
              </div>
            ))
          )
        )}

        {/* COGNITIVE HIDDEN INTENTS (V2 innovate feature) */}
        {filter === "intents" && (
          allHiddenIntents.length === 0 ? (
            <div className="py-12 text-center text-zinc-500 font-mono text-xs flex flex-col items-center justify-center space-y-3">
              <AlertTriangle className="w-10 h-10 text-zinc-700" />
              <span>No hidden intents or unanswered questions parsed in current documents.</span>
            </div>
          ) : (
            allHiddenIntents.map(({ intent, item }) => (
              <div 
                key={intent.id}
                className="p-3.5 rounded-xl border border-zinc-900 bg-zinc-950/50 space-y-2.5"
              >
                <div className="flex justify-between items-start gap-2">
                  <span className={`px-1.5 py-0.2 rounded text-[8px] font-mono uppercase font-bold border ${
                    intent.severity === "high" ? "bg-red-950/20 text-red-400 border-red-900/30" : "bg-zinc-900 text-zinc-400 border-zinc-800"
                  }`}>
                    {intent.type.replace("_", " ")}
                  </span>
                  <span className="text-[9px] text-zinc-500 font-mono">Source: {item.title}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-xs font-bold text-zinc-200 block">{intent.title}</span>
                  <p className="text-[10px] text-zinc-400 leading-normal">{intent.description}</p>
                </div>

                {/* Cognitive Grounding block */}
                <div className="p-2 bg-zinc-900/40 rounded border border-zinc-900 text-[9px] text-zinc-500 font-mono">
                  <span className="text-[8px] uppercase font-bold text-zinc-600 block mb-0.5">Extracted Clause</span>
                  "{intent.context}"
                </div>

                <button
                  onClick={() => onPromoteIntent(intent, item.id)}
                  className="w-full py-1.5 bg-blue-600/10 hover:bg-blue-650/20 text-blue-400 border border-blue-500/10 rounded-lg text-[10px] font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>Promote to Action Checklist</span>
                  <ArrowRight className="w-3 h-3" />
                </button>

              </div>
            ))
          )
        )}

      </div>

    </div>
  );
}
