import fs from "fs";
import path from "path";
import { 
  CapturedItem, 
  Mission, 
  SmartReminder, 
  ChatConversation, 
  UserPreferences, 
  ProductivityStats 
} from "../types";

const DB_DIR = path.join(process.cwd(), "data");
const DB_PATH = path.join(DB_DIR, "db.json");

interface DatabaseSchema {
  capturedItems: CapturedItem[];
  missions: Mission[];
  reminders: SmartReminder[];
  conversations: ChatConversation[];
  preferences: UserPreferences;
  searchHistory: string[];
}

const DEFAULT_PREFS: UserPreferences = {
  ollamaUrl: "http://localhost:11434",
  ollamaModel: "llama3.2",
  aiMode: "gemini", // default to Gemini since it has active API keys, but support selectable local models
  offlineMode: false
};

const DEFAULT_DB: DatabaseSchema = {
  capturedItems: [],
  missions: [],
  reminders: [],
  conversations: [],
  preferences: DEFAULT_PREFS,
  searchHistory: []
};

export class LocalDb {
  private static init() {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2), "utf-8");
    }
  }

  public static read(): DatabaseSchema {
    try {
      this.init();
      const content = fs.readFileSync(DB_PATH, "utf-8");
      return JSON.parse(content);
    } catch (err) {
      console.error("Database read error, returning empty state:", err);
      return DEFAULT_DB;
    }
  }

  public static write(data: Partial<DatabaseSchema>) {
    try {
      this.init();
      const current = this.read();
      const updated = { ...current, ...data };
      fs.writeFileSync(DB_PATH, JSON.stringify(updated, null, 2), "utf-8");
    } catch (err) {
      console.error("Database write error:", err);
    }
  }

  public static clear() {
    try {
      this.init();
      fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2), "utf-8");
    } catch (err) {
      console.error("Database clear error:", err);
    }
  }
}
