import { CapturedItem, UserPreferences } from "../types";

export class SearchService {
  /**
   * Simple and effective cosine similarity calculation
   */
  private static cosineSimilarity(vecA: number[], vecB: number[]): number {
    let dotProduct = 0.0;
    let normA = 0.0;
    let normB = 0.0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Fallback text keyword matcher (TF-IDF approximation)
   */
  private static calculateKeywordScore(text: string, query: string): number {
    const textLower = text.toLowerCase();
    const queryWords = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
    if (queryWords.length === 0) {
      return textLower.includes(query.toLowerCase()) ? 1.0 : 0.0;
    }

    let matches = 0;
    for (const word of queryWords) {
      if (textLower.includes(word)) {
        matches++;
      }
    }
    return matches / queryWords.length;
  }

  /**
   * Local semantic + keyword search engine
   */
  public static async search(
    query: string, 
    items: CapturedItem[], 
    preferences: UserPreferences
  ): Promise<{ item: CapturedItem; score: number }[]> {
    if (!query.trim()) {
      return items.map(item => ({ item, score: 1.0 }));
    }

    const searchResults: { item: CapturedItem; score: number }[] = [];

    // Attempt local semantic embedding search if Ollama is selected
    if (preferences.aiMode === "local" || preferences.aiMode === "hybrid") {
      try {
        console.log("Attempting Ollama semantic embedding generation...");
        const url = `${preferences.ollamaUrl}/api/embeddings`;
        
        // Generate query embedding
        const queryRes = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: preferences.ollamaModel, prompt: query })
        });

        if (queryRes.ok) {
          const queryData = await queryRes.json();
          const queryVec: number[] = queryData.embedding;

          for (const item of items) {
            // Generate item embedding
            const itemRes = await fetch(url, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ model: preferences.ollamaModel, prompt: `${item.title} ${item.content}` })
            });

            if (itemRes.ok) {
              const itemData = await itemRes.json();
              const itemVec: number[] = itemData.embedding;
              const sim = this.cosineSimilarity(queryVec, itemVec);
              searchResults.push({ item, score: sim });
            } else {
              // Keyword fallback for this specific item
              const score = this.calculateKeywordScore(`${item.title} ${item.content}`, query);
              searchResults.push({ item, score });
            }
          }

          // Sort by similarity score descending
          return searchResults.sort((a, b) => b.score - a.score);
        }
      } catch (err) {
        console.warn("Local semantic embedding failed or Ollama not running. Falling back to keyphrase ranking...", err);
      }
    }

    // High fidelity keyphrase matching search
    for (const item of items) {
      const score = this.calculateKeywordScore(`${item.title} ${item.content} ${item.analysis?.summary || ""}`, query);
      if (score > 0 || `${item.title} ${item.content}`.toLowerCase().includes(query.toLowerCase())) {
        searchResults.push({ item, score: Math.max(score, 0.1) });
      }
    }

    return searchResults.sort((a, b) => b.score - a.score);
  }
}
