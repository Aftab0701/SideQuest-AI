export type CaptureType = 
  | "text" 
  | "voice" 
  | "image" 
  | "link" 
  | "document" 
  | "pdf" 
  | "csv" 
  | "markdown" 
  | "calendar" 
  | "email" 
  | "clipboard";

export interface ActionTask {
  id: string;
  missionId?: string;
  title: string;
  priority: "low" | "medium" | "high" | "urgent";
  effort: string; // e.g. "15 mins", "2 hours", "1 day"
  dueDate: string; // YYYY-MM-DD
  status: "todo" | "done";
}

export interface HiddenIntent {
  id: string;
  type: "implied_task" | "unanswered_question" | "forgotten_promise" | "buried_idea" | "potential_risk";
  title: string;
  description: string;
  severity: "low" | "medium" | "high";
  context: string; // why did the AI think this?
}

export interface SmartReminder {
  id: string;
  missionId?: string;
  message: string;
  triggerTime: string; // ISO string or human relative e.g., "In 2 hours"
  frequency: "once" | "daily" | "weekly";
  status: "active" | "snoozed" | "completed";
}

export interface AIAnalysis {
  summary: string;
  confidenceScore: number; // 0 to 100
  suggestedNextStep: string;
  category: string; // "Work" | "Personal" | "Finance" | "Academics" | "Founder Log" | "Life"
  tasks: ActionTask[];
  hiddenIntents: HiddenIntent[];
  reminders: SmartReminder[];
  originalVibe: string; // a short comment about the state of the user when capturing this (e.g. "Hyper-focused but scattered")
}

export interface CapturedItem {
  id: string;
  createdAt: string; // ISO String
  type: CaptureType;
  title: string;
  content: string; // Can be a paste, a transcribed voice, a link URL, metadata about a screenshot
  fileName?: string;
  meta?: {
    duration?: number; // for voice, in seconds
    imageUrl?: string; // for screenshot uploads, base64 or path
    linkUrl?: string; // for links
    fileSize?: string;
    mimeType?: string;
  };
  processed: boolean;
  analysis: AIAnalysis | null;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: string;
  status: "planning" | "active" | "completed";
  tasks: ActionTask[];
  hiddenIntentsCount: number;
  capturedItemIds: string[];
  productivityWeight: number; // point score for completion, e.g. 25
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  createdAt: string;
  sources?: { id: string; title: string }[]; // Citations
}

export interface ChatConversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: string;
}

export interface UserPreferences {
  ollamaUrl: string;
  ollamaModel: string;
  aiMode: "local" | "gemini" | "hybrid";
  offlineMode: boolean;
  apiEndpoint?: string;
}

export interface ProductivityStats {
  score: number; // 0 - 100
  streakDays: number;
  capturedCount: number;
  distilledCount: number;
  completedMissionsCount: number;
  unfinishedIntentsCount: number;
  tasksAtRiskCount: number;
  urgencyNudgesCount: number;
}
