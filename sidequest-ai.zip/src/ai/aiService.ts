import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysis, ActionTask, HiddenIntent, SmartReminder, ChatMessage, UserPreferences } from "../types";

export class AiService {
  private static getGeminiClient(): GoogleGenAI | null {
    if (process.env.GEMINI_API_KEY) {
      return new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return null;
  }

  /**
   * Safe fetch with custom timeout and retry logic
   */
  private static async fetchWithRetry(
    url: string, 
    options: RequestInit, 
    retries = 2, 
    delay = 1000
  ): Promise<Response> {
    for (let i = 0; i <= retries; i++) {
      try {
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), 12000); // 12 second timeout for local Ollama
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(id);
        if (response.ok) return response;
      } catch (err) {
        if (i === retries) throw err;
        console.warn(`Ollama call failed, retrying in ${delay}ms... (${i + 1}/${retries})`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    throw new Error("Failed to contact local AI server after retries.");
  }

  /**
   * Call local Ollama REST API
   */
  private static async callOllama(
    endpoint: string, 
    payload: any, 
    preferences: UserPreferences
  ): Promise<any> {
    const url = `${preferences.ollamaUrl}${endpoint}`;
    const response = await this.fetchWithRetry(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return await response.json();
  }

  /**
   * Main cognitive pipeline router
   */
  public static async analyzeContent(
    content: string, 
    type: string, 
    title: string, 
    preferences: UserPreferences
  ): Promise<AIAnalysis> {
    const systemInstruction = `You are SideQuest AI, an elite, offline-first cognitive engine that acts as a human proxy task optimizer.
You take unstructured imports (text, transcripts, clipboard, files, images) and extract structured intent.

Your core output MUST be a valid JSON object matching this schema exactly:
{
  "summary": "1-sentence summary of what this capture means.",
  "confidenceScore": 95,
  "suggestedNextStep": "A concrete physical command the user should take first.",
  "category": "Work", // Choose from: "Work", "Personal", "Finance", "Academics", "Founder Log", "Life"
  "originalVibe": "Empathetic 3-5 word description of user state (e.g. 'Late-night brainstorm')",
  "tasks": [
    {
      "title": "Actionable title starting with imperative verb",
      "priority": "high", // "low", "medium", "high", "urgent"
      "effort": "30 mins",
      "dueDate": "2026-06-27" // Estimate a logical YYYY-MM-DD format
    }
  ],
  "hiddenIntents": [
    {
      "type": "implied_task", // Choose: "implied_task", "unanswered_question", "forgotten_promise", "buried_idea", "potential_risk"
      "title": "Short descriptive alert heading",
      "description": "Why this is critical and what it threatens if ignored.",
      "severity": "medium", // "low", "medium", "high"
      "context": "Exact words or fragment from prompt that implies this."
    }
  ],
  "reminders": [
    {
      "message": "Clear nudge message",
      "triggerTime": "In 3 hours", // Readable relative timing
      "frequency": "once" // "once", "daily", "weekly"
    }
  ]
}`;

    const prompt = `Capture Title: ${title}
Capture Type: ${type}
Capture Content: "${content}"
Current Time Context: Friday June 26, 2026.

Analyze now and output the JSON structure requested. Return ONLY the raw JSON block without markdown formatting or backticks.`;

    // Local Ollama execution
    if (preferences.aiMode === "local" || preferences.aiMode === "hybrid") {
      try {
        console.log(`Contacting Ollama model: ${preferences.ollamaModel} for analysis...`);
        const result = await this.callOllama("/api/generate", {
          model: preferences.ollamaModel,
          prompt: `${systemInstruction}\n\n${prompt}`,
          format: "json",
          stream: false,
          options: {
            temperature: 0.2
          }
        }, preferences);

        const textResponse = result.response;
        const parsed = JSON.parse(textResponse);
        return this.sanitizeAnalysis(parsed);
      } catch (err) {
        console.warn("Ollama analysis failed.", err);
        if (preferences.aiMode === "local") {
          throw new Error("Ollama model is currently unreachable. Make sure Ollama is running local server ('ollama serve') and model is pulled.");
        }
        console.info("Falling back to cloud Gemini API as hybrid router...");
      }
    }

    // Cloud Gemini API execution
    const gemini = this.getGeminiClient();
    if (!gemini) {
      throw new Error("Both Ollama and Gemini API are unavailable. Please define GEMINI_API_KEY or configure local Ollama in Settings.");
    }

    console.log("Contacting Gemini 3.5 Flash for analysis...");
    const response = await gemini.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["summary", "confidenceScore", "suggestedNextStep", "category", "originalVibe", "tasks", "hiddenIntents", "reminders"],
          properties: {
            summary: { type: Type.STRING },
            confidenceScore: { type: Type.INTEGER },
            suggestedNextStep: { type: Type.STRING },
            category: { type: Type.STRING },
            originalVibe: { type: Type.STRING },
            tasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["title", "priority", "effort", "dueDate"],
                properties: {
                  title: { type: Type.STRING },
                  priority: { type: Type.STRING },
                  effort: { type: Type.STRING },
                  dueDate: { type: Type.STRING }
                }
              }
            },
            hiddenIntents: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["type", "title", "description", "severity", "context"],
                properties: {
                  type: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  severity: { type: Type.STRING },
                  context: { type: Type.STRING }
                }
              }
            },
            reminders: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["message", "triggerTime", "frequency"],
                properties: {
                  message: { type: Type.STRING },
                  triggerTime: { type: Type.STRING },
                  frequency: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    return this.sanitizeAnalysis(parsed);
  }

  /**
   * Question answering on knowledge base documents
   */
  public static async queryKnowledgeBase(
    query: string,
    documentsContext: string,
    history: ChatMessage[],
    preferences: UserPreferences
  ): Promise<string> {
    const systemPrompt = `You are the local knowledge brain of SideQuest AI.
Answer the user's question using ONLY the provided imported documents context. 
If the information is not contained in the documents, state that you cannot find it in their knowledge base.
Be extremely honest, precise, and professional. Citation should refer back to the documents if possible.

Imported Documents Context:
${documentsContext}

Conversation History:
${history.map(h => `${h.sender === "user" ? "User" : "AI"}: ${h.text}`).join("\n")}`;

    const prompt = `User Query: "${query}"
Answer the query clearly:`;

    if (preferences.aiMode === "local" || preferences.aiMode === "hybrid") {
      try {
        console.log(`Contacting Ollama model: ${preferences.ollamaModel} for query...`);
        const result = await this.callOllama("/api/generate", {
          model: preferences.ollamaModel,
          prompt: `${systemPrompt}\n\n${prompt}`,
          stream: false
        }, preferences);
        return result.response;
      } catch (err) {
        console.warn("Ollama chat query failed.", err);
        if (preferences.aiMode === "local") {
          throw new Error("Ollama is offline. Please check your local connection.");
        }
      }
    }

    const gemini = this.getGeminiClient();
    if (!gemini) {
      throw new Error("AI engine is offline. Enable Gemini or verify Ollama connectivity.");
    }

    console.log("Contacting Gemini for knowledge base query...");
    const response = await gemini.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: systemPrompt
      }
    });
    return response.text || "No response received.";
  }

  /**
   * Sanitize AI analysis output structure to match required strict types
   */
  private static sanitizeAnalysis(parsed: any): AIAnalysis {
    const cleanedTasks: ActionTask[] = (parsed.tasks || []).map((t: any, idx: number) => ({
      id: `task-${Date.now()}-${idx}`,
      title: t.title || "Action task",
      priority: ["low", "medium", "high", "urgent"].includes(t.priority) ? t.priority : "medium",
      effort: t.effort || "30 mins",
      dueDate: t.dueDate || new Date().toISOString().split("T")[0],
      status: "todo" as const
    }));

    const cleanedIntents: HiddenIntent[] = (parsed.hiddenIntents || []).map((h: any, idx: number) => ({
      id: `hi-${Date.now()}-${idx}`,
      type: ["implied_task", "unanswered_question", "forgotten_promise", "buried_idea", "potential_risk"].includes(h.type) ? h.type : "implied_task",
      title: h.title || "Inferred context",
      description: h.description || "Implied action required",
      severity: ["low", "medium", "high"].includes(h.severity) ? h.severity : "medium",
      context: h.context || ""
    }));

    const cleanedReminders: SmartReminder[] = (parsed.reminders || []).map((r: any, idx: number) => ({
      id: `rem-${Date.now()}-${idx}`,
      message: r.message || "Friendly nudge",
      triggerTime: r.triggerTime || "Tomorrow at 9 AM",
      frequency: ["once", "daily", "weekly"].includes(r.frequency) ? r.frequency : "once",
      status: "active" as const
    }));

    return {
      summary: parsed.summary || "Parsed unstructured capture.",
      confidenceScore: typeof parsed.confidenceScore === "number" ? parsed.confidenceScore : 85,
      suggestedNextStep: parsed.suggestedNextStep || "Review core details.",
      category: parsed.category || "Work",
      tasks: cleanedTasks,
      hiddenIntents: cleanedIntents,
      reminders: cleanedReminders,
      originalVibe: parsed.originalVibe || "Reflective state"
    };
  }
}
