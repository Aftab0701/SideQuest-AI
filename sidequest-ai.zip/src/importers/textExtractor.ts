export class TextExtractor {
  /**
   * Cleans and structures raw text formats depending on import channel
   */
  public static extract(type: string, title: string, content: string): string {
    const trimmed = content.trim();
    if (!trimmed) return "";

    switch (type) {
      case "csv":
        return this.parseCSV(trimmed);
      case "calendar":
        return this.parseCalendar(trimmed);
      case "email":
        return this.parseEmail(trimmed);
      case "clipboard":
        return `[Imported from Clipboard - ${new Date().toLocaleDateString()}]\n\n${trimmed}`;
      case "pdf":
        return `[Extracted Document Payload: ${title}]\n\n${trimmed}`;
      case "markdown":
        return trimmed;
      default:
        return trimmed;
    }
  }

  /**
   * Transforms raw CSV lines into an easy-to-read textual matrix for LLM consumption
   */
  private static parseCSV(csvText: string): string {
    try {
      const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
      if (lines.length === 0) return "";

      let formatted = "Structured Tabular CSV Data Extracted:\n";
      lines.forEach((line, index) => {
        const columns = line.split(",").map(c => c.trim().replace(/^"|"$/g, ""));
        formatted += `Row ${index + 1}: [ ${columns.join(" | ")} ]\n`;
      });
      return formatted;
    } catch (err) {
      console.warn("CSV parser failed, returning raw text", err);
      return csvText;
    }
  }

  /**
   * Formats unstructured schedule blocks into formal itineraries
   */
  private static parseCalendar(eventText: string): string {
    return `[Structured Calendar Event Details]\n\nSchedule metadata: ${eventText}`;
  }

  /**
   * Scrubs email noise, headers, and signatures for pure conversational thread
   */
  private static parseEmail(emailText: string): string {
    const lines = emailText.split("\n");
    const filtered = lines.filter(line => {
      const lower = line.toLowerCase();
      return (
        !lower.startsWith("from:") &&
        !lower.startsWith("to:") &&
        !lower.startsWith("subject:") &&
        !lower.startsWith("date:") &&
        !lower.startsWith("mime-version:") &&
        !lower.startsWith("content-type:")
      );
    });
    return `[Parsed Email Thread]\n\n${filtered.join("\n").trim()}`;
  }
}
