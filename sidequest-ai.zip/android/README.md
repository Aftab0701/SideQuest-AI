# Building SideQuest AI Mobile APK 📱

This guide explains how to build the SideQuest AI Android app (`.apk`) from this codebase.

## Prerequisites

Before building, ensure you have the following installed on your local computer:
1. **Node.js** (v18 or higher)
2. **Java Development Kit (JDK) 17** (Required for Android Gradle build)
3. **Android Studio** & **Android SDK** (With command-line tools installed)

---

## Simple 1-Click CLI Build Commands

From the root directory of your project, run the following commands:

```bash
# 1. Install all dependencies
npm install

# 2. Build the production React frontend
npx vite build

# 3. Synchronize the web build assets with the Android native project
npx cap sync

# 4. Compile the native Android Debug APK
cd android && ./gradlew assembleDebug
```

Once the compilation completes, your runnable APK file will be located at:
📁 `android/app/build/outputs/apk/debug/app-debug.apk`

You can transfer this APK file directly to your Android device to install and run the app.

---

## Build via Android Studio (Visual GUI Method)

If you prefer using a graphical user interface:

1. Open **Android Studio**.
2. Select **Open an Existing Project** and choose the `android` folder in the root of this project.
3. Wait for Gradle to finish indexing and syncing.
4. In the top menu, go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will build the `.apk` file and show a notification with a **"Locate"** link when finished.

---

## Server Synchronization Configuration

Since mobile apps run in an isolated WebView, relative requests like `/api/capture` will fail. 

We have implemented an **AI Sync Router**:
* **Auto-Discovery**: When running in a web browser, the app automatically syncs with its native host.
* **APK Target Fallback**: When running inside the native APK, the app connects directly to the Cloud Run server:
  `https://ais-dev-lv6rkcyvurlp2lmi6qdqz7-404080228449.asia-southeast1.run.app`
* **Dynamic Override**: You can customize this endpoint anytime. Inside the app, navigate to **System (Settings Tab) > SideQuest Cloud API Sync** and input any custom backend server host URL!
