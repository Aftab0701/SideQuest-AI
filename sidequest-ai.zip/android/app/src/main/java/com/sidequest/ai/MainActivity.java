package com.sidequest.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
