var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_vite = require("vite");
var import_tesseract = __toESM(require("tesseract.js"), 1);

// src/database/localDb.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var DB_DIR = import_path.default.join(process.cwd(), "data");
var DB_PATH = import_path.default.join(DB_DIR, "db.json");
var DEFAULT_PREFS = {
  ollamaUrl: "http://localhost:11434",
  ollamaModel: "llama3.2",
  aiMode: "gemini",
  // default to Gemini since it has active API keys, but support selectable local models
  offlineMode: false
};
var DEFAULT_DB = {
  capturedItems: [],
  missions: [],
  reminders: [],
  conversations: [],
  preferences: DEFAULT_PREFS,
  searchHistory: []
};
var LocalDb = class {
  static init() {
    if (!import_fs.default.existsSync(DB_DIR)) {
      import_fs.default.mkdirSync(DB_DIR, { recursive: true });
    }
    if (!import_fs.default.existsSync(DB_PATH)) {
      import_fs.default.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2), "utf-8");
    }
  }
  static read() {
    try {
      this.init();
      const content = import_fs.default.readFileSync(DB_PATH, "utf-8");
      return JSON.parse(content);
    } catch (err) {
      console.error("Database read error, returning empty state:", err);
      return DEFAULT_DB;
    }
  }
  static write(data) {
    try {
      this.init();
      const current = this.read();
      const updated = { ...current, ...data };
      import_fs.default.writeFileSync(DB_PATH, JSON.stringify(updated, null, 2), "utf-8");
    } catch (err) {
      console.error("Database write error:", err);
    }
  }
  static clear() {
    try {
      this.init();
      import_fs.default.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2), "utf-8");
    } catch (err) {
      console.error("Database clear error:", err);
    }
  }
};

// src/ai/aiService.ts
var import_genai = require("@google/genai");
var AiService = class {
  static getGeminiClient() {
    if (process.env.GEMINI_API_KEY) {
      return new import_genai.GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
    }
    return null;
  }
  /**
   * Safe fetch with custom timeout and retry logic
   */
  static async fetchWithRetry(url, options, retries = 2, delay = 1e3) {
    for (let i = 0; i <= retries; i++) {
      try {
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), 12e3);
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(id);
        if (response.ok) return response;
      } catch (err) {
        if (i === retries) throw err;
        console.warn(`Ollama call failed, retrying in ${delay}ms... (${i + 1}/${retries})`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
    throw new Error("Failed to contact local AI server after retries.");
  }
  /**
   * Call local Ollama REST API
   */
  static async callOllama(endpoint, payload, preferences) {
    const url = `${preferences.ollamaUrl}${endpoint}`;
    const response = await this.fetchWithRetry(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return await response.json();
  }
  /**
   * Main cognitive pipeline router
   */
  static async analyzeContent(content, type, title, preferences) {
    const systemInstruction = `You are SideQuest AI, an elite, offline-first cognitive engine that acts as a human proxy task optimizer.
You take unstructured imports (text, transcripts, clipboard, files, images) and extract structured intent.

Your core output MUST be a valid JSON object matching this schema exactly:
{
  "summary": "1-sentence summary of what this capture means.",
  "confidenceScore": 95,
  "suggestedNextStep": "A concrete physical command the user should take first.",
  "category": "Work", // Choose from: "Work", "Personal", "Finance", "Academics", "Founder Log", "Life"
  "originalVibe": "Empathetic 3-5 word description of user state (e.g. 'Late-night brainstorm')",
  "tasks": [
    {
      "title": "Actionable title starting with imperative verb",
      "priority": "high", // "low", "medium", "high", "urgent"
      "effort": "30 mins",
      "dueDate": "2026-06-27" // Estimate a logical YYYY-MM-DD format
    }
  ],
  "hiddenIntents": [
    {
      "type": "implied_task", // Choose: "implied_task", "unanswered_question", "forgotten_promise", "buried_idea", "potential_risk"
      "title": "Short descriptive alert heading",
      "description": "Why this is critical and what it threatens if ignored.",
      "severity": "medium", // "low", "medium", "high"
      "context": "Exact words or fragment from prompt that implies this."
    }
  ],
  "reminders": [
    {
      "message": "Clear nudge message",
      "triggerTime": "In 3 hours", // Readable relative timing
      "frequency": "once" // "once", "daily", "weekly"
    }
  ]
}`;
    const prompt = `Capture Title: ${title}
Capture Type: ${type}
Capture Content: "${content}"
Current Time Context: Friday June 26, 2026.

Analyze now and output the JSON structure requested. Return ONLY the raw JSON block without markdown formatting or backticks.`;
    if (preferences.aiMode === "local" || preferences.aiMode === "hybrid") {
      try {
        console.log(`Contacting Ollama model: ${preferences.ollamaModel} for analysis...`);
        const result = await this.callOllama("/api/generate", {
          model: preferences.ollamaModel,
          prompt: `${systemInstruction}

${prompt}`,
          format: "json",
          stream: false,
          options: {
            temperature: 0.2
          }
        }, preferences);
        const textResponse = result.response;
        const parsed2 = JSON.parse(textResponse);
        return this.sanitizeAnalysis(parsed2);
      } catch (err) {
        console.warn("Ollama analysis failed.", err);
        if (preferences.aiMode === "local") {
          throw new Error("Ollama model is currently unreachable. Make sure Ollama is running local server ('ollama serve') and model is pulled.");
        }
        console.info("Falling back to cloud Gemini API as hybrid router...");
      }
    }
    const gemini = this.getGeminiClient();
    if (!gemini) {
      throw new Error("Both Ollama and Gemini API are unavailable. Please define GEMINI_API_KEY or configure local Ollama in Settings.");
    }
    console.log("Contacting Gemini 3.5 Flash for analysis...");
    const response = await gemini.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          required: ["summary", "confidenceScore", "suggestedNextStep", "category", "originalVibe", "tasks", "hiddenIntents", "reminders"],
          properties: {
            summary: { type: import_genai.Type.STRING },
            confidenceScore: { type: import_genai.Type.INTEGER },
            suggestedNextStep: { type: import_genai.Type.STRING },
            category: { type: import_genai.Type.STRING },
            originalVibe: { type: import_genai.Type.STRING },
            tasks: {
              type: import_genai.Type.ARRAY,
              items: {
                type: import_genai.Type.OBJECT,
                required: ["title", "priority", "effort", "dueDate"],
                properties: {
                  title: { type: import_genai.Type.STRING },
                  priority: { type: import_genai.Type.STRING },
                  effort: { type: import_genai.Type.STRING },
                  dueDate: { type: import_genai.Type.STRING }
                }
              }
            },
            hiddenIntents: {
              type: import_genai.Type.ARRAY,
              items: {
                type: import_genai.Type.OBJECT,
                required: ["type", "title", "description", "severity", "context"],
                properties: {
                  type: { type: import_genai.Type.STRING },
                  title: { type: import_genai.Type.STRING },
                  description: { type: import_genai.Type.STRING },
                  severity: { type: import_genai.Type.STRING },
                  context: { type: import_genai.Type.STRING }
                }
              }
            },
            reminders: {
              type: import_genai.Type.ARRAY,
              items: {
                type: import_genai.Type.OBJECT,
                required: ["message", "triggerTime", "frequency"],
                properties: {
                  message: { type: import_genai.Type.STRING },
                  triggerTime: { type: import_genai.Type.STRING },
                  frequency: { type: import_genai.Type.STRING }
                }
              }
            }
          }
        }
      }
    });
    const parsed = JSON.parse(response.text || "{}");
    return this.sanitizeAnalysis(parsed);
  }
  /**
   * Question answering on knowledge base documents
   */
  static async queryKnowledgeBase(query, documentsContext, history, preferences) {
    const systemPrompt = `You are the local knowledge brain of SideQuest AI.
Answer the user's question using ONLY the provided imported documents context. 
If the information is not contained in the documents, state that you cannot find it in their knowledge base.
Be extremely honest, precise, and professional. Citation should refer back to the documents if possible.

Imported Documents Context:
${documentsContext}

Conversation History:
${history.map((h) => `${h.sender === "user" ? "User" : "AI"}: ${h.text}`).join("\n")}`;
    const prompt = `User Query: "${query}"
Answer the query clearly:`;
    if (preferences.aiMode === "local" || preferences.aiMode === "hybrid") {
      try {
        console.log(`Contacting Ollama model: ${preferences.ollamaModel} for query...`);
        const result = await this.callOllama("/api/generate", {
          model: preferences.ollamaModel,
          prompt: `${systemPrompt}

${prompt}`,
          stream: false
        }, preferences);
        return result.response;
      } catch (err) {
        console.warn("Ollama chat query failed.", err);
        if (preferences.aiMode === "local") {
          throw new Error("Ollama is offline. Please check your local connection.");
        }
      }
    }
    const gemini = this.getGeminiClient();
    if (!gemini) {
      throw new Error("AI engine is offline. Enable Gemini or verify Ollama connectivity.");
    }
    console.log("Contacting Gemini for knowledge base query...");
    const response = await gemini.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: systemPrompt
      }
    });
    return response.text || "No response received.";
  }
  /**
   * Sanitize AI analysis output structure to match required strict types
   */
  static sanitizeAnalysis(parsed) {
    const cleanedTasks = (parsed.tasks || []).map((t, idx) => ({
      id: `task-${Date.now()}-${idx}`,
      title: t.title || "Action task",
      priority: ["low", "medium", "high", "urgent"].includes(t.priority) ? t.priority : "medium",
      effort: t.effort || "30 mins",
      dueDate: t.dueDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      status: "todo"
    }));
    const cleanedIntents = (parsed.hiddenIntents || []).map((h, idx) => ({
      id: `hi-${Date.now()}-${idx}`,
      type: ["implied_task", "unanswered_question", "forgotten_promise", "buried_idea", "potential_risk"].includes(h.type) ? h.type : "implied_task",
      title: h.title || "Inferred context",
      description: h.description || "Implied action required",
      severity: ["low", "medium", "high"].includes(h.severity) ? h.severity : "medium",
      context: h.context || ""
    }));
    const cleanedReminders = (parsed.reminders || []).map((r, idx) => ({
      id: `rem-${Date.now()}-${idx}`,
      message: r.message || "Friendly nudge",
      triggerTime: r.triggerTime || "Tomorrow at 9 AM",
      frequency: ["once", "daily", "weekly"].includes(r.frequency) ? r.frequency : "once",
      status: "active"
    }));
    return {
      summary: parsed.summary || "Parsed unstructured capture.",
      confidenceScore: typeof parsed.confidenceScore === "number" ? parsed.confidenceScore : 85,
      suggestedNextStep: parsed.suggestedNextStep || "Review core details.",
      category: parsed.category || "Work",
      tasks: cleanedTasks,
      hiddenIntents: cleanedIntents,
      reminders: cleanedReminders,
      originalVibe: parsed.originalVibe || "Reflective state"
    };
  }
};

// src/search/searchService.ts
var SearchService = class {
  /**
   * Simple and effective cosine similarity calculation
   */
  static cosineSimilarity(vecA, vecB) {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }
  /**
   * Fallback text keyword matcher (TF-IDF approximation)
   */
  static calculateKeywordScore(text, query) {
    const textLower = text.toLowerCase();
    const queryWords = query.toLowerCase().split(/\s+/).filter((w) => w.length > 2);
    if (queryWords.length === 0) {
      return textLower.includes(query.toLowerCase()) ? 1 : 0;
    }
    let matches = 0;
    for (const word of queryWords) {
      if (textLower.includes(word)) {
        matches++;
      }
    }
    return matches / queryWords.length;
  }
  /**
   * Local semantic + keyword search engine
   */
  static async search(query, items, preferences) {
    if (!query.trim()) {
      return items.map((item) => ({ item, score: 1 }));
    }
    const searchResults = [];
    if (preferences.aiMode === "local" || preferences.aiMode === "hybrid") {
      try {
        console.log("Attempting Ollama semantic embedding generation...");
        const url = `${preferences.ollamaUrl}/api/embeddings`;
        const queryRes = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: preferences.ollamaModel, prompt: query })
        });
        if (queryRes.ok) {
          const queryData = await queryRes.json();
          const queryVec = queryData.embedding;
          for (const item of items) {
            const itemRes = await fetch(url, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ model: preferences.ollamaModel, prompt: `${item.title} ${item.content}` })
            });
            if (itemRes.ok) {
              const itemData = await itemRes.json();
              const itemVec = itemData.embedding;
              const sim = this.cosineSimilarity(queryVec, itemVec);
              searchResults.push({ item, score: sim });
            } else {
              const score = this.calculateKeywordScore(`${item.title} ${item.content}`, query);
              searchResults.push({ item, score });
            }
          }
          return searchResults.sort((a, b) => b.score - a.score);
        }
      } catch (err) {
        console.warn("Local semantic embedding failed or Ollama not running. Falling back to keyphrase ranking...", err);
      }
    }
    for (const item of items) {
      const score = this.calculateKeywordScore(`${item.title} ${item.content} ${item.analysis?.summary || ""}`, query);
      if (score > 0 || `${item.title} ${item.content}`.toLowerCase().includes(query.toLowerCase())) {
        searchResults.push({ item, score: Math.max(score, 0.1) });
      }
    }
    return searchResults.sort((a, b) => b.score - a.score);
  }
};

// src/importers/textExtractor.ts
var TextExtractor = class {
  /**
   * Cleans and structures raw text formats depending on import channel
   */
  static extract(type, title, content) {
    const trimmed = content.trim();
    if (!trimmed) return "";
    switch (type) {
      case "csv":
        return this.parseCSV(trimmed);
      case "calendar":
        return this.parseCalendar(trimmed);
      case "email":
        return this.parseEmail(trimmed);
      case "clipboard":
        return `[Imported from Clipboard - ${(/* @__PURE__ */ new Date()).toLocaleDateString()}]

${trimmed}`;
      case "pdf":
        return `[Extracted Document Payload: ${title}]

${trimmed}`;
      case "markdown":
        return trimmed;
      default:
        return trimmed;
    }
  }
  /**
   * Transforms raw CSV lines into an easy-to-read textual matrix for LLM consumption
   */
  static parseCSV(csvText) {
    try {
      const lines = csvText.split(/\r?\n/).filter((line) => line.trim().length > 0);
      if (lines.length === 0) return "";
      let formatted = "Structured Tabular CSV Data Extracted:\n";
      lines.forEach((line, index) => {
        const columns = line.split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
        formatted += `Row ${index + 1}: [ ${columns.join(" | ")} ]
`;
      });
      return formatted;
    } catch (err) {
      console.warn("CSV parser failed, returning raw text", err);
      return csvText;
    }
  }
  /**
   * Formats unstructured schedule blocks into formal itineraries
   */
  static parseCalendar(eventText) {
    return `[Structured Calendar Event Details]

Schedule metadata: ${eventText}`;
  }
  /**
   * Scrubs email noise, headers, and signatures for pure conversational thread
   */
  static parseEmail(emailText) {
    const lines = emailText.split("\n");
    const filtered = lines.filter((line) => {
      const lower = line.toLowerCase();
      return !lower.startsWith("from:") && !lower.startsWith("to:") && !lower.startsWith("subject:") && !lower.startsWith("date:") && !lower.startsWith("mime-version:") && !lower.startsWith("content-type:");
    });
    return `[Parsed Email Thread]

${filtered.join("\n").trim()}`;
  }
};

// server.ts
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
app.use(import_express.default.urlencoded({ limit: "50mb", extended: true }));
function calculateProductivityStats(items, missions, reminders) {
  const processedCount = items.filter((i) => i.processed).length;
  const totalTasks = missions.reduce((acc, m) => acc + (m.tasks ? m.tasks.length : 0), 0);
  const doneTasks = missions.reduce((acc, m) => acc + (m.tasks ? m.tasks.filter((t) => t.status === "done").length : 0), 0);
  let score = 0;
  if (totalTasks > 0) {
    score = Math.round(doneTasks / totalTasks * 60 + processedCount / Math.max(1, items.length) * 40);
  } else if (processedCount > 0) {
    score = Math.round(processedCount / items.length * 40);
  }
  score = Math.max(0, Math.min(100, score));
  let unfinishedIntentsCount = 0;
  items.forEach((item) => {
    if (item.processed && item.analysis?.hiddenIntents) {
      unfinishedIntentsCount += item.analysis.hiddenIntents.length;
    }
  });
  let tasksAtRiskCount = 0;
  let activeUrgentReminders = reminders.filter((r) => r.status === "active").length;
  missions.forEach((m) => {
    if (m.tasks) {
      m.tasks.forEach((t) => {
        if (t.status === "todo") {
          const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
          const isOverdueOrSoon = t.dueDate <= todayStr;
          if (t.priority === "urgent" || t.priority === "high" && isOverdueOrSoon) {
            tasksAtRiskCount++;
          }
        }
      });
    }
  });
  const hasCompletedTasks = doneTasks > 0;
  const streakDays = hasCompletedTasks ? 6 : 0;
  return {
    score,
    streakDays,
    capturedCount: items.length,
    distilledCount: processedCount,
    completedMissionsCount: missions.filter((m) => m.status === "completed").length,
    unfinishedIntentsCount,
    tasksAtRiskCount,
    urgencyNudgesCount: activeUrgentReminders + tasksAtRiskCount
  };
}
app.get("/api/data", (req, res) => {
  const db = LocalDb.read();
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.json({
    capturedItems: db.capturedItems,
    missions: db.missions,
    reminders: db.reminders,
    conversations: db.conversations,
    preferences: db.preferences,
    searchHistory: db.searchHistory,
    stats
  });
});
app.post("/api/preferences", (req, res) => {
  const { preferences } = req.body;
  if (!preferences) {
    return res.status(400).json({ error: "Missing preferences payload" });
  }
  LocalDb.write({ preferences });
  res.json({ success: true, preferences });
});
app.post("/api/capture", async (req, res) => {
  const { type, title, content, meta, fileName } = req.body;
  if (!type) {
    return res.status(400).json({ error: "Missing capture type" });
  }
  let finalContent = content || "";
  let extractedMeta = meta || {};
  if (type === "image" && content && content.startsWith("data:image")) {
    try {
      console.log("Image received. Extracting text via local Tesseract OCR...");
      const base64Data = content.replace(/^data:image\/\w+;base64,/, "");
      const imageBuffer = Buffer.from(base64Data, "base64");
      const ocrResult = await import_tesseract.default.recognize(imageBuffer, "eng");
      finalContent = ocrResult.data.text.trim();
      console.log("OCR success! Extracted text length:", finalContent.length);
      if (!finalContent) {
        finalContent = "[Empty screenshot / whiteboard with no readable printed text]";
      }
      extractedMeta = {
        ...extractedMeta,
        ocrProcessed: true,
        wordCount: finalContent.split(/\s+/).length
      };
    } catch (err) {
      console.error("Local Tesseract OCR failed:", err);
      finalContent = "[OCR text extraction failure - unreadable image format]";
    }
  } else {
    finalContent = TextExtractor.extract(type, title || "Untitled file", finalContent);
  }
  const db = LocalDb.read();
  const newItem = {
    id: `cap-${Date.now()}`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    type,
    title: title || `Messy fragment (${type})`,
    content: finalContent,
    fileName,
    meta: extractedMeta,
    processed: false,
    analysis: null
  };
  db.capturedItems.unshift(newItem);
  LocalDb.write({ capturedItems: db.capturedItems });
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.status(201).json({ item: newItem, stats });
});
app.post("/api/analyze/:id", async (req, res) => {
  const { id } = req.params;
  const db = LocalDb.read();
  const item = db.capturedItems.find((i) => i.id === id);
  if (!item) {
    return res.status(404).json({ error: "Captured item not found" });
  }
  try {
    const analysis = await AiService.analyzeContent(
      item.content,
      item.type,
      item.title,
      db.preferences
    );
    item.processed = true;
    item.analysis = analysis;
    const newMission = {
      id: `mis-${Date.now()}`,
      title: `Mission: Distill ${item.title}`,
      description: analysis.summary,
      category: analysis.category,
      status: "active",
      tasks: analysis.tasks,
      hiddenIntentsCount: analysis.hiddenIntents.length,
      capturedItemIds: [item.id],
      productivityWeight: analysis.tasks.length * 10 + analysis.hiddenIntents.length * 5,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.missions.unshift(newMission);
    analysis.reminders.forEach((rem) => {
      db.reminders.unshift({
        ...rem,
        missionId: newMission.id
      });
    });
    LocalDb.write({
      capturedItems: db.capturedItems,
      missions: db.missions,
      reminders: db.reminders
    });
    const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
    res.json({
      item,
      mission: newMission,
      reminders: db.reminders,
      stats
    });
  } catch (err) {
    console.error("AI pipeline failed:", err);
    res.status(500).json({ error: err.message || "Cognitive pipeline execution failed." });
  }
});
app.post("/api/tasks/toggle", (req, res) => {
  const { missionId, taskId } = req.body;
  if (!taskId) {
    return res.status(400).json({ error: "Missing taskId" });
  }
  const db = LocalDb.read();
  db.missions = db.missions.map((m) => {
    if (!missionId || m.id === missionId) {
      const updatedTasks = m.tasks.map((t) => {
        if (t.id === taskId) {
          return { ...t, status: t.status === "todo" ? "done" : "todo" };
        }
        return t;
      });
      return { ...m, tasks: updatedTasks };
    }
    return m;
  });
  db.capturedItems = db.capturedItems.map((item) => {
    if (item.processed && item.analysis) {
      const updatedTasks = item.analysis.tasks.map((t) => {
        if (t.id === taskId) {
          return { ...t, status: t.status === "todo" ? "done" : "todo" };
        }
        return t;
      });
      return { ...item, analysis: { ...item.analysis, tasks: updatedTasks } };
    }
    return item;
  });
  LocalDb.write({
    missions: db.missions,
    capturedItems: db.capturedItems
  });
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.json({ success: true, missions: db.missions, stats });
});
app.post("/api/missions/toggle", (req, res) => {
  const { missionId } = req.body;
  if (!missionId) {
    return res.status(400).json({ error: "Missing missionId" });
  }
  const db = LocalDb.read();
  db.missions = db.missions.map((m) => {
    if (m.id === missionId) {
      const nextStatus = m.status === "completed" ? "active" : "completed";
      const updatedTasks = m.tasks.map((t) => ({
        ...t,
        status: nextStatus === "completed" ? "done" : "todo"
      }));
      return { ...m, status: nextStatus, tasks: updatedTasks };
    }
    return m;
  });
  LocalDb.write({ missions: db.missions });
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.json({ success: true, missions: db.missions, stats });
});
app.post("/api/reminders/toggle", (req, res) => {
  const { reminderId, status } = req.body;
  if (!reminderId) {
    return res.status(400).json({ error: "Missing reminderId" });
  }
  const db = LocalDb.read();
  db.reminders = db.reminders.map((r) => {
    if (r.id === reminderId) {
      return { ...r, status: status || "completed" };
    }
    return r;
  });
  LocalDb.write({ reminders: db.reminders });
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.json({ reminders: db.reminders, stats });
});
app.post("/api/merge", (req, res) => {
  const { sourceId, targetId } = req.body;
  const db = LocalDb.read();
  const sourceItem = db.capturedItems.find((i) => i.id === sourceId);
  const targetItem = db.capturedItems.find((i) => i.id === targetId);
  if (!sourceItem || !targetItem) {
    return res.status(404).json({ error: "One or both items not found" });
  }
  targetItem.content = `${targetItem.content}

[Merged from Capture: ${sourceItem.title}]
${sourceItem.content}`;
  targetItem.title = `${targetItem.title} + ${sourceItem.title}`;
  targetItem.processed = false;
  targetItem.analysis = null;
  db.capturedItems = db.capturedItems.filter((i) => i.id !== sourceId);
  LocalDb.write({ capturedItems: db.capturedItems });
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.json({ capturedItems: db.capturedItems, stats });
});
app.post("/api/search", async (req, res) => {
  const { query } = req.body;
  const db = LocalDb.read();
  if (query && !db.searchHistory.includes(query)) {
    db.searchHistory.unshift(query);
    if (db.searchHistory.length > 10) db.searchHistory.pop();
    LocalDb.write({ searchHistory: db.searchHistory });
  }
  const results = await SearchService.search(query, db.capturedItems, db.preferences);
  res.json({ results });
});
app.post("/api/chat", async (req, res) => {
  const { conversationId, text } = req.body;
  if (!text) {
    return res.status(400).json({ error: "Missing query text" });
  }
  const db = LocalDb.read();
  let conversation = db.conversations.find((c) => c.id === conversationId);
  if (!conversation) {
    conversation = {
      id: conversationId || `chat-${Date.now()}`,
      title: text.substring(0, 30) + "...",
      messages: [],
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.conversations.unshift(conversation);
  }
  const processedItems = db.capturedItems.filter((i) => i.processed);
  let kbContext = "";
  if (processedItems.length === 0) {
    kbContext = "The user has not imported or processed any documents yet. Encourage them to capture their first item.";
  } else {
    processedItems.forEach((item, idx) => {
      kbContext += `
--- DOCUMENT #${idx + 1} (Title: ${item.title}, Category: ${item.analysis?.category || "Unknown"}) ---
`;
      kbContext += `Summary: ${item.analysis?.summary || ""}
`;
      kbContext += `Extracted Content:
${item.content}
`;
      if (item.analysis?.tasks) {
        kbContext += `Extracted Tasks: ${item.analysis.tasks.map((t) => t.title).join(", ")}
`;
      }
    });
  }
  const userMsg = {
    id: `msg-${Date.now()}-u`,
    sender: "user",
    text,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  conversation.messages.push(userMsg);
  try {
    const aiResponseText = await AiService.queryKnowledgeBase(
      text,
      kbContext,
      conversation.messages,
      db.preferences
    );
    const citedSources = [];
    processedItems.forEach((item) => {
      const isCited = aiResponseText.toLowerCase().includes(item.title.toLowerCase()) || text.toLowerCase().includes(item.title.toLowerCase());
      if (isCited) {
        citedSources.push({ id: item.id, title: item.title });
      }
    });
    const aiMsg = {
      id: `msg-${Date.now()}-ai`,
      sender: "ai",
      text: aiResponseText,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      sources: citedSources.length > 0 ? citedSources : void 0
    };
    conversation.messages.push(aiMsg);
    conversation.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    LocalDb.write({ conversations: db.conversations });
    res.json({ conversation });
  } catch (err) {
    console.error("Knowledge base query failed:", err);
    res.status(500).json({ error: err.message || "AI local search query failed." });
  }
});
app.post("/api/reset", (req, res) => {
  LocalDb.clear();
  const db = LocalDb.read();
  const stats = calculateProductivityStats(db.capturedItems, db.missions, db.reminders);
  res.json({
    capturedItems: db.capturedItems,
    missions: db.missions,
    reminders: db.reminders,
    conversations: db.conversations,
    preferences: db.preferences,
    searchHistory: db.searchHistory,
    stats
  });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SideQuest V2 Mobile Core active on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
